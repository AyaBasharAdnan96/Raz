package com.example.raz;

import android.support.v7.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    //initializing the variables of the login page
    private Button Login;
    private Button Signup;
    private EditText Name;
    private EditText Password;

    DatabaseHandler myDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );
        myDb = new DatabaseHandler(this);

        Name = (EditText) findViewById(R.id.etName);
        Password = (EditText) findViewById( R.id.etPassword );

        Login = (Button) findViewById( R.id.btnLogin );
        Signup = (Button) findViewById( R.id.btnSingup );

        //Activating Singup button
        Login.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent( MainActivity.this, Login.class );
                startActivity( intent );
            }
        });

        Signup.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent( MainActivity.this, SecondActivity.class );
                startActivity( intent );
            }
        });

    }//end of onCreate function

  //Function to validate
    private void validate(){
        if (Name.equals( "aya" )){
            if (Password.equals( "10" )){
                Intent intent = new Intent( MainActivity.this, Login.class );
                startActivity(intent);
            }
        }
    }


}
